import{d as s,o as n,g as l,c as o,a as e,t as r,b as u,e as i}from"./index-bQFRraM2.js";const f=s({__name:"Stats",setup(p){const t=u(null);return n(async()=>{t.value=await l("/api/stats")}),(c,a)=>(i(),o("main",null,[a[0]||(a[0]=e("h1",null,"Stats",-1)),e("pre",null,r(JSON.stringify(t.value,null,2)),1)]))}});export{f as default};
//# sourceMappingURL=Stats-D_ArgKZB.js.map

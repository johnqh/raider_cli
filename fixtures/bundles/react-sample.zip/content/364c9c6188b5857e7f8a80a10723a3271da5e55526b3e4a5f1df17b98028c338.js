import{r as s,g as r,j as t}from"./index-B6zGc9AK.js";function i(){const[e,a]=s.useState(null);return s.useEffect(()=>{r("/api/stats").then(a)},[]),t.jsxs("main",{children:[t.jsx("h1",{children:"Stats"}),t.jsx("pre",{children:JSON.stringify(e,null,2)})]})}export{i as default};
//# sourceMappingURL=Stats-Vq6xNloI.js.map

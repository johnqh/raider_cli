import{u as n,r,g as i,j as t}from"./index-B6zGc9AK.js";function u(){const{id:s}=n(),[e,a]=r.useState(null);return r.useEffect(()=>{i(`/api/users/${s}`).then(a)},[s]),t.jsxs("main",{children:[t.jsxs("h1",{children:["User ",s]}),t.jsx("p",{children:(e==null?void 0:e.name)??"loading"})]})}export{u as default};
//# sourceMappingURL=UserDetail-Bg8A-sFR.js.map

import{r,g as n,j as e}from"./index-B6zGc9AK.js";function u(){const[t,i]=r.useState([]);return r.useEffect(()=>{n("/api/users").then(s=>i(s.users))},[]),e.jsxs("main",{children:[e.jsx("h1",{children:"Users"}),e.jsx("ul",{children:t.map(s=>e.jsx("li",{children:s.name},s.id))})]})}export{u as default};
//# sourceMappingURL=Users-CqHBajCK.js.map
